# Cinematic AI Pro — APK banane ke steps (Hindi)

## Computer par Android Studio se
1. `CinematicAIPro_Android_Full_Project.zip` ko extract karein.
2. Android Studio install karke extracted `CinematicAIPro` folder open karein.
3. Android SDK Platform 35 install karein, agar prompt aaye to.
4. Gradle sync complete hone dein.
5. Menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. APK yahan milega: `app/build/outputs/apk/debug/app-debug.apk`.
7. APK ko apne Android phone par bhej kar install karein. Phone settings me sirf trusted source ke liye install permission dein.

## GitHub Actions se build
Project ko GitHub repository me upload karein. `main` ya `master` branch par push karne ke baad **Actions → Build Android APK** workflow chal jayega. Successful run me `CinematicAIPro-debug-apk` artifact se APK download karein. Is workflow ko yahan run nahi kiya gaya hai.

## Backend chalana zaroori hai
Photo Smart Enhance aur video grading ke liye backend ko server/computer par chalana hoga. `backend/README.md` dekhein. Phone par `10.0.2.2` kaam nahi karta; phone ke liye computer ka reachable LAN IP ya HTTPS domain set karein. Online AI enhancement ke liye compatible provider aur API key backend par configure karein. API key Android app me kabhi na rakhein.
