# Cinematic AI Pro — Android app project

Premium black-and-gold Android app source built with Kotlin and Jetpack Compose.

## Included in this project
- Photo/video picker and photo preview.
- 4K / 8K / 10K requested photo output options.
- Online AI photo enhancement via a configurable provider, plus a real local Smart Enhance endpoint (contrast, color, sharpening, and upscaling) that works without an AI key; results save to `Pictures/CinematicAIPro`.
- 61 named cinematic video looks.
- Real video grading/export workflow: uploads the selected video to `POST /grade-video`, uses server-side FFmpeg to render an MP4, and saves the result to `Movies/CinematicAIPro`.
- Backend URL is tucked into the settings button.
- FastAPI backend, allow-listed FFmpeg filter mapping, upload limits, Dockerfile, and backend smoke tests.

## Important honest status
This is a substantially functional **source project**, not a compiled or device-tested APK. The current environment has no Android SDK/Gradle installation, so I could not compile or install-test the APK here. Android Studio is needed to build it. True generative/AI super-resolution still requires a real image-enhancement provider configured on the backend; no paid API key or AI provider subscription is bundled. Smart Enhance is available without a key but uses conventional image processing and cannot invent missing details. Video grading works when the backend is running with FFmpeg installed (the included Dockerfile installs FFmpeg).

## Run the backend
See `backend/README.md`. For local Android emulator testing, use `http://10.0.2.2:8000`; on a physical phone, use a reachable computer/server IP. For production, deploy behind HTTPS.

## Build an APK
1. Install Android Studio and the Android SDK.
2. Open this folder (`CinematicAIPro`) in Android Studio.
3. Let Gradle sync complete and install SDK Platform 35 if prompted.
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK is usually produced at `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.cinematicai.pro`


## Quick backend test
From the `backend` folder, install the requirements and run `python test_api.py`. This tests health, preset catalog, and local Smart Enhance using a generated sample image.

## Build APK through GitHub Actions
The project includes `.github/workflows/android.yml`. Upload the project to a GitHub repository and run the workflow (or push to `main`); it builds a debug APK and publishes it as a workflow artifact. This workflow has not been run in this environment.
