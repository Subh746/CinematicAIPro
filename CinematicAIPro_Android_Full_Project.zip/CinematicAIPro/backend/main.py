import os
from io import BytesIO
from typing import Literal

import httpx
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError

app = FastAPI(title="Cinematic AI Pro API", version="0.1.0")
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "15"))
ALLOWED_TYPES = {"image/jpeg", "image/png", "image/webp"}


@app.get("/health")
def health():
    return {"status": "ok", "service": "Cinematic AI Pro API"}


@app.post("/enhance")
async def enhance(
    file: UploadFile = File(...),
    output: Literal["4K", "8K", "10K"] = "8K",
):
    """
    Secure integration point for an online image-enhancement provider.
    Configure AI_PROVIDER_URL and AI_PROVIDER_API_KEY on the server.
    The provider must accept multipart `file` and `output` fields and return
    the enhanced image bytes as image/*; adapt the request mapping to the
    provider's documented API before production use.
    """
    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, "Upload a JPG, PNG, or WebP image.")

    data = await file.read()
    if not data:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File is larger than {MAX_UPLOAD_MB} MB.")

    try:
        with Image.open(BytesIO(data)) as image:
            if image.width * image.height > 80_000_000:
                raise HTTPException(413, "Image dimensions exceed the 80 megapixel input limit.")
            image.verify()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise HTTPException(400, "The uploaded file is not a valid image.")

    provider_url = os.getenv("AI_PROVIDER_URL", "").strip()
    api_key = os.getenv("AI_PROVIDER_API_KEY", "").strip()
    if not provider_url or not api_key or "your-ai-provider.example" in provider_url:
        raise HTTPException(
            503,
            "AI provider is not configured. Set AI_PROVIDER_URL and "
            "AI_PROVIDER_API_KEY on the backend.",
        )

    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            result = await client.post(
                provider_url,
                headers={"Authorization": f"Bearer {api_key}"},
                files={"file": (file.filename or "photo.jpg", data, file.content_type)},
                data={"output": output},
            )
    except httpx.HTTPError:
        raise HTTPException(502, "Could not reach the AI provider.")

    if result.status_code >= 400:
        raise HTTPException(502, "The AI provider returned an error.")
    content_type = result.headers.get("content-type", "application/octet-stream")
    if not content_type.startswith("image/"):
        raise HTTPException(
            502,
            "Provider response was not an image. Adapt backend/main.py to the "
            "provider's actual response format.",
        )
    # Normalize provider output to PNG because the Android client saves this route as PNG.
    try:
        with Image.open(BytesIO(result.content)) as enhanced:
            normalized = BytesIO()
            enhanced.convert("RGBA" if "A" in enhanced.getbands() else "RGB").save(normalized, format="PNG", optimize=True)
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise HTTPException(502, "The AI provider returned invalid or oversized image data.")
    return Response(
        content=normalized.getvalue(),
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="cinematic-enhanced.png"'},
    )


@app.post("/smart-enhance")
async def smart_enhance(
    file: UploadFile = File(...),
    output: Literal["4K", "8K", "10K"] = "8K",
):
    """Local non-generative enhancement + upscale using Pillow.

    This is a practical offline-style fallback, not an AI super-resolution model.
    The longest edge targets 3840, 7680, or 10240 pixels; aspect ratio is kept.
    A pixel cap protects the server from extreme memory use.
    """
    from PIL import ImageEnhance, ImageFilter, ImageOps

    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(415, "Upload a JPG, PNG, or WebP image.")
    data = await file.read(MAX_UPLOAD_MB * 1024 * 1024 + 1)
    if not data:
        raise HTTPException(400, "The uploaded file is empty.")
    if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
        raise HTTPException(413, f"File is larger than {MAX_UPLOAD_MB} MB.")

    targets = {"4K": 3840, "8K": 7680, "10K": 10240}
    try:
        with Image.open(BytesIO(data)) as original:
            if original.width * original.height > 80_000_000:
                raise HTTPException(413, "Image dimensions exceed the 80 megapixel input limit.")
            image = ImageOps.exif_transpose(original).convert("RGB")
            image.thumbnail((targets[output], targets[output]), Image.Resampling.LANCZOS)
            width, height = image.size
            scale = targets[output] / max(width, height)
            new_width = max(1, round(width * scale))
            new_height = max(1, round(height * scale))
            # Do not exceed 100 megapixels to avoid exhausting server memory.
            if new_width * new_height > 100_000_000:
                factor = (100_000_000 / (new_width * new_height)) ** 0.5
                new_width = max(1, int(new_width * factor))
                new_height = max(1, int(new_height * factor))
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
            image = ImageOps.autocontrast(image, cutoff=0.3)
            image = ImageEnhance.Color(image).enhance(1.06)
            image = ImageEnhance.Contrast(image).enhance(1.04)
            image = image.filter(ImageFilter.UnsharpMask(radius=1.4, percent=125, threshold=3))
            output_buffer = BytesIO()
            image.save(output_buffer, format="PNG", optimize=True)
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
        raise HTTPException(400, "The uploaded file is not a valid or supported image.")

    return Response(
        content=output_buffer.getvalue(),
        media_type="image/png",
        headers={"Content-Disposition": 'attachment; filename="cinematic-smart-enhanced.png"'},
    )

# Safe, server-side FFmpeg looks. Preset names are mapped here rather than
# accepting arbitrary filter strings from a client.
VIDEO_FILTERS = {
    "Teal & Orange": "eq=saturation=1.18:contrast=1.08,colorbalance=rs=0.08:gs=-0.02:bs=-0.08:rm=0.05:bm=-0.03",
    "Hollywood": "eq=contrast=1.12:saturation=1.08:brightness=-0.01,colorbalance=bs=-0.04:rm=0.04",
    "Bollywood": "eq=saturation=1.28:contrast=1.06:brightness=0.02,colorbalance=rs=0.06:gs=0.02",
    "Vintage": "eq=saturation=0.72:contrast=0.92:brightness=0.03,colorbalance=rs=0.05:gs=0.02:bs=-0.04",
    "Dark Mood": "eq=brightness=-0.06:contrast=1.18:saturation=0.82",
    "HDR": "eq=contrast=1.18:saturation=1.18:gamma=0.96",
    "Forest": "eq=saturation=1.12,colorbalance=gs=0.07:bs=-0.02",
    "Golden Hour": "colorbalance=rs=0.12:gs=0.04:bs=-0.10,eq=saturation=1.08:brightness=0.02",
    "Blue Hour": "colorbalance=bs=0.14:gs=-0.02:rs=-0.06,eq=saturation=0.9:brightness=-0.02",
    "Cyberpunk": "eq=saturation=1.35:contrast=1.12,colorbalance=rs=0.05:bs=0.12:gs=-0.04",
    "Noir": "hue=s=0,eq=contrast=1.35:brightness=-0.02",
    "Cinematic Warm": "colorbalance=rs=0.09:gs=0.02:bs=-0.08,eq=saturation=1.04",
    "Cinematic Cool": "colorbalance=rs=-0.05:gs=-0.01:bs=0.10,eq=saturation=0.95",
    "Desert Sand": "colorbalance=rs=0.10:gs=0.03:bs=-0.10,eq=saturation=0.82:brightness=0.02",
    "Arctic Blue": "colorbalance=bs=0.16:gs=0.01:rs=-0.08,eq=saturation=0.86",
    "Neon Night": "eq=saturation=1.4:contrast=1.12,colorbalance=bs=0.10:rs=0.04",
    "Moody Green": "colorbalance=gs=0.12:rs=-0.04:bs=-0.04,eq=saturation=0.9:contrast=1.08",
    "Pastel Dream": "eq=saturation=0.78:contrast=0.88:brightness=0.05",
    "Retro 70s": "eq=saturation=0.8:contrast=0.9:brightness=0.04,colorbalance=rs=0.08:gs=0.03:bs=-0.06",
    "Retro 90s": "eq=saturation=0.92:contrast=1.05,colorbalance=rs=0.03:bs=-0.03",
    "Film Fade": "eq=contrast=0.82:brightness=0.04:saturation=0.82",
    "Kodak Film": "eq=saturation=1.06:contrast=1.03,colorbalance=rs=0.05:gs=0.01:bs=-0.04",
    "Fuji Film": "eq=saturation=1.08:contrast=1.04,colorbalance=gs=0.04:bs=0.02",
    "Portra Style": "eq=saturation=0.9:contrast=0.94:brightness=0.02,colorbalance=rs=0.06:gs=0.02:bs=-0.04",
    "Black & White": "hue=s=0,eq=contrast=1.12",
    "Matte Black": "eq=contrast=0.88:brightness=0.01:saturation=0.8",
    "High Contrast": "eq=contrast=1.28:saturation=1.05",
    "Soft Contrast": "eq=contrast=0.86:saturation=0.96:brightness=0.02",
    "Wedding Glow": "eq=brightness=0.05:contrast=0.92:saturation=0.9,gblur=sigma=0.25",
    "Romantic": "eq=brightness=0.025:contrast=0.92:saturation=0.92,colorbalance=rs=0.04",
    "Dreamy": "eq=brightness=0.04:contrast=0.86:saturation=0.88,gblur=sigma=0.2",
    "Sunset Glow": "colorbalance=rs=0.12:gs=0.03:bs=-0.11,eq=saturation=1.15:brightness=0.02",
    "Ocean Blue": "colorbalance=bs=0.13:gs=-0.01:rs=-0.05,eq=saturation=1.08",
    "Rainy Day": "eq=saturation=0.72:brightness=-0.02:contrast=1.04,colorbalance=bs=0.04",
    "Storm Mood": "eq=saturation=0.65:brightness=-0.05:contrast=1.18,colorbalance=bs=0.06",
    "Action Movie": "eq=contrast=1.2:saturation=1.08,unsharp=5:5:0.5:3:3:0.0",
    "Sci-Fi": "eq=saturation=1.28:contrast=1.12,colorbalance=bs=0.10:gs=0.03",
    "Fantasy": "eq=saturation=1.1:brightness=0.025:contrast=0.94,colorbalance=bs=0.04:rs=0.03",
    "Horror": "eq=saturation=0.65:brightness=-0.07:contrast=1.2,colorbalance=gs=0.06:bs=0.03",
    "Thriller": "eq=saturation=0.78:brightness=-0.03:contrast=1.16,colorbalance=bs=0.04",
    "Documentary": "eq=saturation=0.95:contrast=1.04",
    "Travel Vlog": "eq=saturation=1.16:contrast=1.06:brightness=0.015",
    "Food Pop": "eq=saturation=1.28:contrast=1.08:brightness=0.02",
    "Portrait Skin": "eq=saturation=0.96:contrast=0.96:brightness=0.015",
    "Urban Grit": "eq=saturation=0.78:contrast=1.22:brightness=-0.02",
    "Street Film": "eq=saturation=0.86:contrast=1.08,colorbalance=rs=0.04:bs=-0.03",
    "Luxury Gold": "colorbalance=rs=0.12:gs=0.04:bs=-0.12,eq=contrast=1.08:saturation=0.94",
    "Emerald": "colorbalance=gs=0.13:rs=-0.04:bs=-0.02,eq=saturation=1.08",
    "Crimson": "colorbalance=rs=0.13:gs=-0.04:bs=-0.02,eq=saturation=1.1",
    "Purple Haze": "colorbalance=rs=0.05:bs=0.12:gs=-0.04,eq=saturation=1.08",
    "Monochrome Blue": "hue=s=0,colorbalance=bs=0.12:rs=-0.05",
    "Bleach Bypass": "eq=saturation=0.55:contrast=1.28:brightness=-0.015",
    "Cross Process": "colorbalance=rs=0.08:gs=-0.03:bs=0.08,eq=contrast=1.12:saturation=1.12",
    "Crisp Natural": "eq=contrast=1.05:saturation=1.04,unsharp=5:5:0.35:3:3:0.0",
    "Soft Natural": "eq=contrast=0.95:saturation=0.96:brightness=0.01",
    "Epic Teal": "colorbalance=bs=0.12:gs=-0.02:rs=0.05,eq=contrast=1.12:saturation=1.12",
    "Orange Crush": "colorbalance=rs=0.13:gs=0.03:bs=-0.10,eq=saturation=1.18",
    "Low-Key": "eq=brightness=-0.07:contrast=1.15:saturation=0.9",
    "High-Key": "eq=brightness=0.07:contrast=0.9:saturation=0.92",
    "Night Vision Style": "colorbalance=gs=0.15:rs=-0.05:bs=-0.04,eq=contrast=1.1:saturation=0.9",
    "Autumn Leaves": "colorbalance=rs=0.11:gs=0.03:bs=-0.10,eq=saturation=1.08",
}


@app.post("/grade-video")
async def grade_video(
    file: UploadFile = File(...),
    preset: str = "Teal & Orange",
):
    """Render a real MP4 using a named, allow-listed FFmpeg color look.

    The server must have the `ffmpeg` executable installed. Uploads are bounded
    and temporary files are removed after each request.
    """
    import shutil
    import subprocess
    import tempfile
    from pathlib import Path

    if not file.content_type or not file.content_type.startswith("video/"):
        raise HTTPException(415, "Upload a video file (MP4/MOV).")
    if preset not in VIDEO_FILTERS:
        raise HTTPException(400, "Unknown video preset.")
    if not shutil.which("ffmpeg"):
        raise HTTPException(503, "FFmpeg is not installed on this server. Install FFmpeg and restart the API.")

    max_video_mb = int(os.getenv("MAX_VIDEO_UPLOAD_MB", "300"))
    data = await file.read(max_video_mb * 1024 * 1024 + 1)
    if not data:
        raise HTTPException(400, "The uploaded video is empty.")
    if len(data) > max_video_mb * 1024 * 1024:
        raise HTTPException(413, f"Video is larger than {max_video_mb} MB.")

    with tempfile.TemporaryDirectory(prefix="cinematic-ai-") as workdir:
        source = Path(workdir) / "source_video"
        output = Path(workdir) / "graded.mp4"
        source.write_bytes(data)
        command = [
            "ffmpeg", "-hide_banner", "-loglevel", "error", "-y",
            "-i", str(source), "-vf", VIDEO_FILTERS[preset],
            "-map", "0:v:0", "-map", "0:a?", "-c:v", "libx264",
            "-preset", "veryfast", "-crf", os.getenv("VIDEO_CRF", "20"),
            "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k",
            "-movflags", "+faststart", str(output),
        ]
        try:
            result = subprocess.run(command, capture_output=True, text=True, timeout=900, check=False)
        except subprocess.TimeoutExpired:
            raise HTTPException(504, "Video rendering timed out. Try a shorter or smaller video.")
        if result.returncode != 0 or not output.exists() or output.stat().st_size == 0:
            detail = (result.stderr or "FFmpeg could not decode or render this file.")[-500:]
            raise HTTPException(422, f"Video rendering failed: {detail}")
        rendered = output.read_bytes()

    return Response(
        content=rendered,
        media_type="video/mp4",
        headers={"Content-Disposition": 'attachment; filename="cinematic-graded.mp4"'},
    )


@app.get("/presets")
def list_video_presets():
    """Return the exact video looks available to the renderer."""
    return {"presets": list(VIDEO_FILTERS.keys()), "count": len(VIDEO_FILTERS)}
