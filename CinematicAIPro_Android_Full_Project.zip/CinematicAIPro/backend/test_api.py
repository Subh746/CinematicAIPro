"""Small smoke tests for the Cinematic AI Pro backend; run: python test_api.py"""
from io import BytesIO
import shutil
import subprocess
import tempfile
from pathlib import Path
from fastapi.testclient import TestClient
from PIL import Image

from main import app, VIDEO_FILTERS

client = TestClient(app)


def make_image() -> bytes:
    image = Image.new("RGB", (96, 64), (80, 120, 160))
    output = BytesIO()
    image.save(output, format="PNG")
    return output.getvalue()


def main() -> None:
    response = client.get("/health")
    assert response.status_code == 200, response.text
    assert response.json()["status"] == "ok"

    response = client.get("/presets")
    assert response.status_code == 200, response.text
    assert response.json()["count"] == len(VIDEO_FILTERS) >= 50

    response = client.post(
        "/smart-enhance?output=4K",
        files={"file": ("sample.png", make_image(), "image/png")},
    )
    assert response.status_code == 200, response.text
    assert response.headers["content-type"].startswith("image/png")
    with Image.open(BytesIO(response.content)) as result:
        assert result.size == (3840, 2560), result.size

    response = client.post(
        "/smart-enhance?output=4K",
        files={"file": ("bad.txt", b"not an image", "text/plain")},
    )
    assert response.status_code == 415, response.text

    if shutil.which("ffmpeg"):
        with tempfile.TemporaryDirectory(prefix="cinematic-test-") as folder:
            sample = Path(folder) / "sample.mp4"
            subprocess.run(
                ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "lavfi",
                 "-i", "testsrc=size=160x120:rate=12:duration=1", "-pix_fmt", "yuv420p",
                 "-c:v", "libx264", "-y", str(sample)],
                check=True,
                capture_output=True,
            )
            response = client.post(
                "/grade-video?preset=Teal%20%26%20Orange",
                files={"file": ("sample.mp4", sample.read_bytes(), "video/mp4")},
            )
            assert response.status_code == 200, response.text
            assert response.headers["content-type"].startswith("video/mp4")
            assert response.content[:4] == b"\x00\x00\x00\x18" or response.content[4:8] == b"ftyp"

    print("PASS: health, 61 presets, Smart Enhance 4K output, invalid upload, and FFmpeg video grading")


if __name__ == "__main__":
    main()
