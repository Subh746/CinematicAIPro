# Cinematic AI Pro API

FastAPI backend for photo-provider integration and real MP4 video color grading.

## What works
- `GET /health` — API health check.
- `GET /presets` — returns all 61 supported video looks.
- `POST /grade-video?preset=Teal%20%26%20Orange` — accepts a multipart `file` video and returns a rendered MP4. Requires FFmpeg (included in the Docker image).
- `POST /enhance?output=4K|8K|10K` — validates an image upload and forwards it to a configured image-enhancement provider. This endpoint intentionally does not pretend to perform AI itself; configure a real provider below.
- `POST /smart-enhance?output=4K|8K|10K` — runs local Pillow contrast/color/sharpening and upscaling. It needs no AI API key, but is not generative AI and cannot reconstruct details that were never captured.

## Run locally
1. Install Python 3.11+ and FFmpeg (`ffmpeg -version` should work).
2. `python -m venv .venv` and activate it.
3. `pip install -r requirements.txt`
4. Configure `AI_PROVIDER_URL` and `AI_PROVIDER_API_KEY` in your shell (see `.env.example`). The provider must accept multipart `file` and `output` fields and return image bytes; adapt the request mapping to its documented API if needed.
5. `uvicorn main:app --host 0.0.0.0 --port 8000`

For local emulator testing, the Android app's default `http://10.0.2.2:8000` reaches a development server on the host computer. A physical phone needs a reachable LAN address; a production app should use HTTPS.

## Test
Run `python test_api.py` from this folder after installing requirements.

## Docker
From this folder:

```sh
docker build -t cinematic-ai-pro-api .
docker run --rm -p 8000:8000 \
  -e AI_PROVIDER_URL='https://provider.example/your-endpoint' \
  -e AI_PROVIDER_API_KEY='your-secret-key' \
  cinematic-ai-pro-api
```

Do not commit secrets or put provider keys in the Android app.

## Limits and production hardening
- `MAX_UPLOAD_MB` defaults to 15 for photos; `MAX_VIDEO_UPLOAD_MB` defaults to 300 for videos.
- Video rendering can be CPU-intensive. The request timeout is 15 minutes; try shorter clips if rendering times out.
- Use HTTPS, authentication, rate limits, quotas, and request-size limits at the reverse proxy. Consider asynchronous jobs/object storage for larger production workloads.
- Uploaded files are processed in temporary directories and deleted after the request; avoid logging private media or API keys.
- 4K/8K/10K output depends on the chosen provider and source image; a label in the app does not guarantee the provider can produce that size.
