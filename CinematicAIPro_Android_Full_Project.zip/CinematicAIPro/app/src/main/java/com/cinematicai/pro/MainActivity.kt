package com.cinematicai.pro

import android.content.ContentValues
import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import coil.compose.AsyncImage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val Ink = Color(0xFF0B0B0D)
private val Panel = Color(0xFF19191D)
private val Gold = Color(0xFFD8AD55)
private val Muted = Color(0xFFB7B7BE)

private val cinematicPresets = listOf(
    "Teal & Orange", "Hollywood", "Bollywood", "Vintage", "Dark Mood", "HDR", "Forest",
    "Golden Hour", "Blue Hour", "Cyberpunk", "Noir", "Cinematic Warm", "Cinematic Cool", "Desert Sand",
    "Arctic Blue", "Neon Night", "Moody Green", "Pastel Dream", "Retro 70s", "Retro 90s", "Film Fade",
    "Kodak Film", "Fuji Film", "Portra Style", "Black & White", "Matte Black", "High Contrast", "Soft Contrast",
    "Wedding Glow", "Romantic", "Dreamy", "Sunset Glow", "Ocean Blue", "Rainy Day", "Storm Mood",
    "Action Movie", "Sci-Fi", "Fantasy", "Horror", "Thriller", "Documentary", "Travel Vlog",
    "Food Pop", "Portrait Skin", "Urban Grit", "Street Film", "Luxury Gold", "Emerald", "Crimson",
    "Purple Haze", "Monochrome Blue", "Bleach Bypass", "Cross Process", "Crisp Natural", "Soft Natural",
    "Epic Teal", "Orange Crush", "Low-Key", "High-Key", "Night Vision Style", "Autumn Leaves"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CinematicApp() }
    }
}

@Composable
fun CinematicApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("cinematic_ai_pro", Context.MODE_PRIVATE) }
    var selectedTab by remember { mutableStateOf("Photo AI") }
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Choose a photo or video to get started.") }
    var preset by remember { mutableStateOf("Teal & Orange") }
    var resolution by remember { mutableStateOf("8K") }
    var backendUrl by remember { mutableStateOf(prefs.getString("backend_url", "http://10.0.2.2:8000") ?: "http://10.0.2.2:8000") }
    var showSettings by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(backendUrl) {
        prefs.edit().putString("backend_url", backendUrl.trim()).apply()
    }

    val mediaPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            pickedUri = uri
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            status = "Media selected. Tap Enhance with AI to send it to your configured backend."
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Gold,
            background = Ink,
            surface = Panel,
            onPrimary = Ink,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(containerColor = Ink) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Ink)
                    .padding(horizontal = 20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Spacer(Modifier.height(26.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(48.dp).background(Gold, RoundedCornerShape(15.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Ink)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("CINEMATIC AI PRO", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Black)
                        Text("AI ENHANCER  •  COLOR STUDIO", color = Muted, fontSize = 10.sp, letterSpacing = 1.3.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { showSettings = !showSettings }) {
                        Icon(Icons.Default.Settings, contentDescription = "Backend settings", tint = Gold)
                    }
                }
                Spacer(Modifier.height(26.dp))
                Text("Make every frame", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Text("look cinematic.", color = Gold, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("Enhance photos and grade videos with a premium workflow.", color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatusPill("60+ LOOKS")
                    StatusPill("4K / 8K / 10K")
                    StatusPill("LOCAL EXPORT")
                }
                Spacer(Modifier.height(24.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModeCard("Photo AI", "4K • 8K • 10K", Icons.Default.Photo, selectedTab == "Photo AI", Modifier.weight(1f)) {
                        if (selectedTab != "Photo AI") { selectedTab = "Photo AI"; pickedUri = null; status = "Choose a photo to get started." }
                    }
                    ModeCard("Video Grade", "Cinematic LUTs", Icons.Default.Movie, selectedTab == "Video Grade", Modifier.weight(1f)) {
                        if (selectedTab != "Video Grade") { selectedTab = "Video Grade"; pickedUri = null; status = "Choose a video to get started." }
                    }
                }

                Spacer(Modifier.height(20.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp)) {
                        Text(if (selectedTab == "Photo AI") "PHOTO ENHANCER" else "VIDEO COLOR GRADING",
                            color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Spacer(Modifier.height(14.dp))
                        Box(
                            modifier = Modifier.fillMaxWidth().height(190.dp)
                                .background(Color(0xFF242429), RoundedCornerShape(16.dp))
                                .clickable {
                                    pickedUri = null
                                    mediaPicker.launch(arrayOf(if (selectedTab == "Photo AI") "image/*" else "video/*"))
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (pickedUri != null && selectedTab == "Photo AI") {
                                AsyncImage(model = pickedUri, contentDescription = "Selected photo", modifier = Modifier.fillMaxSize())
                                Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0xCC101014)).padding(8.dp)) {
                                    Text("PHOTO SELECTED  •  TAP TO CHANGE", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(if (selectedTab == "Photo AI") Icons.Default.Photo else Icons.Default.Movie,
                                        contentDescription = null, tint = Gold, modifier = Modifier.size(38.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text(if (pickedUri == null) "Tap to upload ${if (selectedTab == "Photo AI") "photo" else "video"}" else "Video selected",
                                        color = Color.White, fontWeight = FontWeight.SemiBold)
                                    Text(if (selectedTab == "Photo AI") "JPG • PNG • WEBP" else "MP4 • MOV • M4V", color = Muted, fontSize = 12.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Text(status, color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(12.dp))
                        if (showSettings) {
                            OutlinedTextField(
                                value = backendUrl,
                                onValueChange = { backendUrl = it },
                                label = { Text("API server URL") },
                                placeholder = { Text("https://your-server.example") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth(),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, focusedLabelColor = Gold, cursorColor = Gold)
                            )
                            Text("Emulator: 10.0.2.2. Phone: enter your reachable server IP or HTTPS domain.", color = Muted, fontSize = 10.sp)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    if (!busy) {
                                        busy = true
                                        status = "Checking backend connection…"
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) {
                                                try { checkBackend(backendUrl.trim()) }
                                                catch (e: Exception) { "Connection failed: ${e.message ?: "check URL and server"}" }
                                            }
                                            status = result
                                            busy = false
                                        }
                                    }
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)
                            ) { Text("Test server connection") }
                            Spacer(Modifier.height(16.dp))
                        }

                        if (selectedTab == "Photo AI") {
                            Text("OUTPUT RESOLUTION", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf("4K", "8K", "10K").forEach { item ->
                                    FilterChip(
                                        selected = resolution == item,
                                        onClick = { resolution = item },
                                        label = { Text(item) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Gold,
                                            selectedLabelColor = Ink
                                        )
                                    )
                                }
                            }
                            Button(
                                onClick = {
                                    val uri = pickedUri
                                    if (uri == null) {
                                        status = "Please select a photo first."
                                    } else if (backendUrl.isBlank()) {
                                        status = "Enter your backend URL first."
                                    } else if (!busy) {
                                        busy = true
                                        status = "Uploading photo to AI backend…"
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) {
                                                try {
                                                    val bytes = uploadForEnhancement(context, uri, backendUrl.trim(), resolution)
                                                    val saved = saveEnhancedImage(context, bytes)
                                                    "Enhanced image saved to Pictures/CinematicAIPro."
                                                } catch (e: Exception) {
                                                    "Processing failed: ${e.message ?: "check backend URL and AI provider setup"}"
                                                }
                                            }
                                            status = result
                                            busy = false
                                        }
                                    }
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                                shape = RoundedCornerShape(14.dp)
                            ) { Text(if (busy) "Processing…" else "Enhance with AI • $resolution", fontWeight = FontWeight.Bold) }
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    val uri = pickedUri
                                    if (uri == null) status = "Please select a photo first."
                                    else if (backendUrl.isBlank()) status = "Enter your backend URL first."
                                    else if (!busy) {
                                        busy = true
                                        status = "Running Smart Enhance and upscaling to $resolution…"
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) {
                                                try {
                                                    val bytes = uploadForEnhancement(context, uri, backendUrl.trim(), resolution, "/smart-enhance")
                                                    saveEnhancedImage(context, bytes)
                                                    "Smart Enhanced image saved to Pictures/CinematicAIPro. This uses local image processing, not generative AI."
                                                } catch (e: Exception) {
                                                    "Smart Enhance failed: ${e.message ?: "check backend URL"}"
                                                }
                                            }
                                            status = result
                                            busy = false
                                        }
                                    }
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold),
                                shape = RoundedCornerShape(14.dp)
                            ) { Text("Smart Enhance • No AI key needed", fontWeight = FontWeight.SemiBold) }
                        } else {
                            Text("COLOR PRESETS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                cinematicPresets.forEach { item ->
                                    FilterChip(
                                        selected = preset == item,
                                        onClick = { preset = item },
                                        label = { Text(item) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Gold,
                                            selectedLabelColor = Ink
                                        )
                                    )
                                }
                            }
                            Text("Preset selected: $preset", color = Muted, fontSize = 12.sp)
                            Button(
                                onClick = {
                                    val uri = pickedUri
                                    if (uri == null) status = "Please select a video first."
                                    else if (backendUrl.isBlank()) status = "Open settings and enter your API server URL."
                                    else if (!busy) {
                                        busy = true
                                        status = "Rendering $preset video… keep the app open."
                                        scope.launch {
                                            val result = withContext(Dispatchers.IO) {
                                                try {
                                                    val bytes = uploadForVideoGrade(context, uri, backendUrl.trim(), preset)
                                                    saveGradedVideo(context, bytes)
                                                    "Done! Graded video saved to Movies/CinematicAIPro."
                                                } catch (e: Exception) {
                                                    "Export failed: ${e.message ?: "check server connection and FFmpeg setup"}"
                                                }
                                            }
                                            status = result
                                            busy = false
                                        }
                                    }
                                },
                                enabled = !busy,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink),
                                shape = RoundedCornerShape(14.dp)
                            ) { Text(if (busy) "Rendering video…" else "Apply $preset & Export MP4", fontWeight = FontWeight.Bold) }
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("PRO WORKFLOW", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(10.dp))
                Text("• Enhance with AI requires a compatible image-enhancement provider configured on your server.\n• Smart Enhance works without an AI key using contrast, sharpening and upscaling; it is not generative AI.\n• Video grading uses FFmpeg on the server and exports an MP4.\n• 4K / 8K / 10K are target long-edge sizes, with a 100 MP server safety cap.\n• Media is sent to the server you configure; use a trusted HTTPS server for private media.",
                    color = Muted, fontSize = 13.sp, lineHeight = 21.sp)
                Spacer(Modifier.height(30.dp))
            }
        }
    }
}

private fun checkBackend(baseUrl: String): String {
    val connection = (URL(baseUrl.trimEnd('/') + "/health").openConnection() as HttpURLConnection).apply {
        requestMethod = "GET"
        connectTimeout = 8000
        readTimeout = 8000
    }
    return try {
        val code = connection.responseCode
        if (code !in 200..299) "Backend responded with HTTP $code."
        else "Connected successfully to Cinematic AI Pro backend."
    } finally { connection.disconnect() }
}

private fun uploadForEnhancement(context: Context, uri: Uri, baseUrl: String, output: String, path: String = "/enhance"): ByteArray {
    val boundary = "----CinematicAIPro-${UUID.randomUUID()}"
    val connection = (URL(baseUrl.trimEnd('/') + path + "?output=" + output).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 15000
        readTimeout = 180000
        doOutput = true
        setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        setRequestProperty("Accept", "image/*, application/json")
    }
    try {
        connection.outputStream.use { out ->
            val mimeType = context.contentResolver.getType(uri)?.takeIf { it in setOf("image/jpeg", "image/png", "image/webp") } ?: "image/jpeg"
            val name = when (mimeType) { "image/png" -> "upload.png"; "image/webp" -> "upload.webp"; else -> "upload.jpg" }
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"$name\"\r\nContent-Type: $mimeType\r\n\r\n".toByteArray())
            context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out) }
                ?: throw IllegalStateException("Could not read selected photo")
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = connection.responseCode
        if (code !in 200..299) {
            val message = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            throw IllegalStateException("Backend HTTP $code: ${message.take(220)}")
        }
        val type = connection.contentType.orEmpty()
        if (!type.startsWith("image/")) {
            val message = connection.inputStream.bufferedReader().use { it.readText() }
            throw IllegalStateException(message.take(220).ifBlank { "Backend did not return an image" })
        }
        return connection.inputStream.use { it.readBytes() }
    } finally {
        connection.disconnect()
    }
}

private fun uploadForVideoGrade(context: Context, uri: Uri, baseUrl: String, preset: String): ByteArray {
    val boundary = "----CinematicAIPro-${UUID.randomUUID()}"
    val encodedPreset = java.net.URLEncoder.encode(preset, "UTF-8")
    val connection = (URL(baseUrl.trimEnd('/') + "/grade-video?preset=" + encodedPreset).openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 600000
        doOutput = true
        setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
        setRequestProperty("Accept", "video/mp4, application/json")
    }
    try {
        connection.outputStream.use { out ->
            val mimeType = context.contentResolver.getType(uri)?.takeIf { it.startsWith("video/") } ?: "video/mp4"
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"source.mp4\"\r\nContent-Type: $mimeType\r\n\r\n".toByteArray())
            context.contentResolver.openInputStream(uri)?.use { input -> input.copyTo(out) }
                ?: throw IllegalStateException("Could not read selected video")
            out.write("\r\n--$boundary--\r\n".toByteArray())
        }
        val code = connection.responseCode
        if (code !in 200..299) {
            val message = connection.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
            throw IllegalStateException("Server HTTP $code: ${message.take(250)}")
        }
        if (!connection.contentType.orEmpty().startsWith("video/")) {
            val message = connection.inputStream.bufferedReader().use { it.readText() }
            throw IllegalStateException(message.take(250).ifBlank { "Server did not return an MP4 video" })
        }
        return connection.inputStream.use { it.readBytes() }
    } finally { connection.disconnect() }
}

private fun saveGradedVideo(context: Context, bytes: ByteArray): Uri {
    if (bytes.isEmpty()) throw IllegalStateException("The server returned an empty video")
    val values = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "CinematicAIPro_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CinematicAIPro")
    }
    val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("Could not create output video")
    try {
        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: throw IllegalStateException("Could not write output video")
    } catch (e: Exception) {
        context.contentResolver.delete(uri, null, null)
        throw e
    }
    return uri
}

private fun saveEnhancedImage(context: Context, bytes: ByteArray): Uri {
    if (bytes.isEmpty()) throw IllegalStateException("The backend returned an empty image")
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "CinematicAIPro_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CinematicAIPro")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("Could not create output image")
    try {
        context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            ?: throw IllegalStateException("Could not write output image")
    } catch (e: Exception) {
        context.contentResolver.delete(uri, null, null)
        throw e
    }
    return uri
}

@Composable
private fun StatusPill(text: String) {
    Surface(color = Color(0xFF201B12), shape = RoundedCornerShape(50), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF554323))) {
        Text(text, modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp), color = Gold, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun ModeCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF302719) else Panel),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Gold else Color(0xFF303036)),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, contentDescription = null, tint = Gold, modifier = Modifier.size(25.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}
